"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useChat } from "ai/react"
import { Droplet, Cpu, Leaf, AlertTriangle, BarChart3, RefreshCw, Users, Network, Zap, Home } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

// Updated regions data with community initiatives
const REGIONS = [
  {
    id: "amazonia",
    name: "Amazon Rainforest",
    description: "Tropical forest with rich biodiversity and indigenous communities",
    position: { x: 0.35, y: 0.65 },
    resources: {
      water: 90,
      energy: 30,
      minerals: 60,
      biodiversity: 95,
      community: 80,
      dataStorage: 10,
    },
    extractionPoints: [
      { name: "Bauxite Mine", type: "minerals", x: 0.3, y: 0.4 },
      { name: "Belo Monte Dam", type: "energy", x: 0.6, y: 0.3 },
      { name: "Indigenous Reserve", type: "community", x: 0.5, y: 0.6 },
      { name: "Amazon AWS Data Center", type: "dataStorage", x: 0.7, y: 0.5 },
    ],
    dataCenters: [
      { name: "Amazon AWS (Manaus)", x: 0.7, y: 0.5, waterUsage: "High", powerCapacity: "60 MW" },
      { name: "Equinix (São Paulo)", x: 0.8, y: 0.8, waterUsage: "Medium", powerCapacity: "30 MW" },
    ],
    waterConsumption: [
      { name: "AWS Cooling System", x: 0.65, y: 0.45, intensity: "High" },
      { name: "Belo Monte Hydroelectric", x: 0.55, y: 0.25, intensity: "Very High" },
    ],
    communityInitiatives: [
      {
        name: "AI Tainá",
        description: "Indigenous knowledge preservation AI system",
        x: 0.4,
        y: 0.6,
        impact: "High",
        website: "https://aitaina.org",
      },
      {
        name: "Forest Guardian Network",
        description: "Community-led AI monitoring of deforestation",
        x: 0.3,
        y: 0.5,
        impact: "Medium",
        website: "https://forestguardians.org",
      },
    ],
  },
  {
    id: "atacama",
    name: "Atacama Desert (Chile)",
    description: "Region rich in lithium, essential for electronic device batteries",
    position: { x: 0.25, y: 0.75 },
    resources: {
      water: 10,
      energy: 80,
      minerals: 95,
      biodiversity: 30,
      community: 40,
      dataStorage: 20,
    },
    extractionPoints: [
      { name: "Lithium Mine", type: "minerals", x: 0.4, y: 0.3 },
      { name: "Solar Plant", type: "energy", x: 0.7, y: 0.4 },
      { name: "Local Community", type: "community", x: 0.3, y: 0.7 },
      { name: "Endangered Aquifer", type: "water", x: 0.6, y: 0.6 },
    ],
    dataCenters: [
      { name: "Google Data Center (Santiago)", x: 0.8, y: 0.7, waterUsage: "Very High", powerCapacity: "80 MW" },
      { name: "Huawei Data Center (Antofagasta)", x: 0.5, y: 0.2, waterUsage: "High", powerCapacity: "45 MW" },
    ],
    waterConsumption: [
      { name: "Lithium Extraction", x: 0.45, y: 0.35, intensity: "Extreme" },
      { name: "Google Data Center Cooling", x: 0.75, y: 0.65, intensity: "Very High" },
      { name: "Depleted Aquifer", x: 0.55, y: 0.55, intensity: "Critical" },
    ],
    communityInitiatives: [
      {
        name: "Water Justice AI",
        description: "Community monitoring of water resources",
        x: 0.35,
        y: 0.65,
        impact: "Medium",
        website: "https://waterjustice.org",
      },
    ],
  },
  {
    id: "congo",
    name: "Democratic Republic of Congo",
    description: "Main source of cobalt, used in electronic device batteries",
    position: { x: 0.55, y: 0.65 },
    resources: {
      water: 70,
      energy: 20,
      minerals: 90,
      biodiversity: 80,
      community: 60,
      dataStorage: 5,
    },
    extractionPoints: [
      { name: "Cobalt Mine", type: "minerals", x: 0.5, y: 0.4 },
      { name: "Endangered Forest", type: "biodiversity", x: 0.3, y: 0.6 },
      { name: "Local Village", type: "community", x: 0.7, y: 0.7 },
      { name: "Contaminated River", type: "water", x: 0.2, y: 0.3 },
    ],
    dataCenters: [
      { name: "iColo Data Center (Kinshasa)", x: 0.8, y: 0.3, waterUsage: "Medium", powerCapacity: "15 MW" },
    ],
    waterConsumption: [
      { name: "Cobalt Processing", x: 0.55, y: 0.45, intensity: "High" },
      { name: "River Contamination", x: 0.25, y: 0.35, intensity: "Severe" },
    ],
    communityInitiatives: [
      {
        name: "Fair Mining AI",
        description: "Tracking ethical sourcing of minerals",
        x: 0.6,
        y: 0.6,
        impact: "Medium",
        website: "https://fairmining.org",
      },
    ],
  },
  {
    id: "siliconvalley",
    name: "Silicon Valley (USA)",
    description: "Global technology center and headquarters of major AI companies",
    position: { x: 0.2, y: 0.4 },
    resources: {
      water: 50,
      energy: 95,
      minerals: 10,
      biodiversity: 40,
      community: 70,
      dataStorage: 95,
    },
    extractionPoints: [
      { name: "Google Data Center", type: "dataStorage", x: 0.4, y: 0.3 },
      { name: "Power Plant", type: "energy", x: 0.7, y: 0.5 },
      { name: "Water Reservoir", type: "water", x: 0.2, y: 0.6 },
      { name: "Tech Campus", type: "community", x: 0.6, y: 0.7 },
    ],
    dataCenters: [
      { name: "Google (Mountain View)", x: 0.4, y: 0.3, waterUsage: "Extreme", powerCapacity: "120 MW" },
      { name: "Meta (Menlo Park)", x: 0.5, y: 0.5, waterUsage: "Very High", powerCapacity: "100 MW" },
      { name: "Apple (Cupertino)", x: 0.3, y: 0.4, waterUsage: "High", powerCapacity: "90 MW" },
      { name: "Microsoft (Santa Clara)", x: 0.6, y: 0.4, waterUsage: "Very High", powerCapacity: "110 MW" },
      { name: "OpenAI (San Francisco)", x: 0.5, y: 0.2, waterUsage: "Extreme", powerCapacity: "150 MW" },
    ],
    waterConsumption: [
      { name: "Data Center Cooling", x: 0.45, y: 0.35, intensity: "Extreme" },
      { name: "Depleted Reservoir", x: 0.25, y: 0.55, intensity: "Critical" },
      { name: "AI Model Training", x: 0.55, y: 0.25, intensity: "Extreme" },
    ],
    communityInitiatives: [
      {
        name: "Open Source AI Coalition",
        description: "Democratizing AI development",
        x: 0.65,
        y: 0.65,
        impact: "High",
        website: "https://opensourceai.org",
      },
      {
        name: "Tech Ethics Collective",
        description: "Promoting ethical AI development",
        x: 0.35,
        y: 0.55,
        impact: "Medium",
        website: "https://techethics.org",
      },
    ],
  },
  {
    id: "canada",
    name: "Northern Canada",
    description: "Indigenous territories with growing AI sovereignty initiatives",
    position: { x: 0.3, y: 0.25 },
    resources: {
      water: 95,
      energy: 60,
      minerals: 70,
      biodiversity: 85,
      community: 90,
      dataStorage: 30,
    },
    extractionPoints: [
      { name: "Rare Earth Mine", type: "minerals", x: 0.6, y: 0.3 },
      { name: "Hydroelectric Dam", type: "energy", x: 0.4, y: 0.4 },
      { name: "Indigenous Territory", type: "community", x: 0.5, y: 0.5 },
      { name: "Research Center", type: "dataStorage", x: 0.7, y: 0.6 },
    ],
    dataCenters: [
      { name: "Concordia University AI Lab", x: 0.7, y: 0.6, waterUsage: "Low", powerCapacity: "5 MW" },
      { name: "Northern Data Center", x: 0.3, y: 0.3, waterUsage: "Medium", powerCapacity: "20 MW" },
    ],
    waterConsumption: [{ name: "Hydroelectric Impact", x: 0.45, y: 0.45, intensity: "Medium" }],
    communityInitiatives: [
      {
        name: "Indigenous AI Sovereignty",
        description: "Concordia University-led program indigenizing AI",
        x: 0.5,
        y: 0.5,
        impact: "High",
        website: "https://www.concordia.ca/indigenizing-ai",
      },
      {
        name: "Northern Knowledge AI",
        description: "Preserving traditional knowledge through community-owned AI",
        x: 0.4,
        y: 0.6,
        impact: "High",
        website: "https://northernknowledge.org",
      },
      {
        name: "Indigenous Data Sovereignty Network",
        description: "Ensuring indigenous control over data and AI",
        x: 0.6,
        y: 0.4,
        impact: "Very High",
        website: "https://indigenousdatasov.org",
      },
    ],
  },
]

// Real-time data simulation
const generateRealTimeData = () => {
  return {
    globalWaterUsage: Math.floor(Math.random() * 500000 + 1500000), // Liters per minute
    activeDataCenters: Math.floor(Math.random() * 100 + 8000), // Number of active data centers
    aiModelTraining: Math.floor(Math.random() * 50 + 150), // Number of large models in training
    carbonEmissions: Math.floor(Math.random() * 2000 + 8000), // Tons per hour
    communityInitiatives: Math.floor(Math.random() * 10 + 250), // Number of active initiatives
  }
}

export default function ExtractionGame() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat()
  const [selectedRegion, setSelectedRegion] = useState<(typeof REGIONS)[0] | null>(null)
  const [resources, setResources] = useState(REGIONS[0].resources)
  const [totalImpact, setTotalImpact] = useState(0)
  const [showStats, setShowStats] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [mode, setMode] = useState<"extractive" | "sustainable">("extractive")
  const [hoveredPoint, setHoveredPoint] = useState<{ name: string; type?: string; description?: string } | null>(null)
  const [realTimeData, setRealTimeData] = useState(generateRealTimeData())
  const [showCommunityInitiatives, setShowCommunityInitiatives] = useState(true)
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [zoomLevel, setZoomLevel] = useState(1)
  const [viewState, setViewState] = useState<"planet" | "region">("planet")
  const [zoomTarget, setZoomTarget] = useState<{ x: number; y: number } | null>(null)
  const [zoomTransition, setZoomTransition] = useState(0)
  const [hoveredRegion, setHoveredRegion] = useState<(typeof REGIONS)[0] | null>(null)
  const [gameIntro, setGameIntro] = useState(true)
  const [gameStage, setGameStage] = useState(0)

  // Update resources when region changes
  useEffect(() => {
    if (selectedRegion) {
      setResources(selectedRegion.resources)
      setTotalImpact(0)
    }
  }, [selectedRegion])

  // Real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData(generateRealTimeData())
      setLastUpdate(new Date())
    }, 5000) // Update every 5 seconds

    return () => clearInterval(interval)
  }, [])

  // Calculate impact based on message length and complexity
  useEffect(() => {
    if (messages.length > 0 && messages[messages.length - 1].role === "assistant" && selectedRegion) {
      const lastMessage = messages[messages.length - 1].content
      const length = lastMessage.length

      // Calculate resource impact based on message length
      const waterImpact = mode === "extractive" ? length * 0.03 : length * 0.005
      const energyImpact = mode === "extractive" ? length * 0.05 : length * 0.01
      const mineralsImpact = mode === "extractive" ? length * 0.04 : length * 0.008
      const biodiversityImpact = mode === "extractive" ? length * 0.03 : length * 0.006
      const communityImpact = mode === "extractive" ? -length * 0.02 : length * 0.02
      const dataStorageImpact = mode === "extractive" ? length * 0.06 : length * 0.015

      setResources((prev) => ({
        water: Math.max(0, Math.min(prev.water - waterImpact, 100)),
        energy: Math.max(0, Math.min(prev.energy - energyImpact, 100)),
        minerals: Math.max(0, Math.min(prev.minerals - mineralsImpact, 100)),
        biodiversity: Math.max(0, Math.min(prev.biodiversity - biodiversityImpact, 100)),
        community: Math.max(0, Math.min(prev.community + communityImpact, 100)),
        dataStorage: Math.min(prev.dataStorage + dataStorageImpact, 100),
      }))

      setTotalImpact((prev) => prev + length * (mode === "extractive" ? 0.1 : 0.03))
    }
  }, [messages, mode, selectedRegion])

  // Handle zoom transition
  useEffect(() => {
    if (zoomTarget) {
      let animationFrame: number
      const animate = () => {
        setZoomTransition((prev) => {
          const newValue = Math.min(prev + 0.02, 1)
          if (newValue >= 1) {
            // Transition complete
            if (viewState === "planet") {
              setViewState("region")
              const region = REGIONS.find(
                (r) => Math.abs(r.position.x - zoomTarget.x) < 0.1 && Math.abs(r.position.y - zoomTarget.y) < 0.1,
              )
              if (region) {
                setSelectedRegion(region)
              }
            } else {
              setViewState("planet")
              setSelectedRegion(null)
            }
            setZoomTarget(null)
            setZoomTransition(0)
            return 1
          }
          animationFrame = requestAnimationFrame(animate)
          return newValue
        })
      }

      animationFrame = requestAnimationFrame(animate)
      return () => cancelAnimationFrame(animationFrame)
    }
  }, [zoomTarget, viewState])

  // Game intro progression
  useEffect(() => {
    if (gameIntro) {
      const timer = setTimeout(() => {
        if (gameStage < 3) {
          setGameStage((prev) => prev + 1)
        } else {
          setGameIntro(false)
        }
      }, 4000)

      return () => clearTimeout(timer)
    }
  }, [gameIntro, gameStage])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = canvas.clientWidth
    canvas.height = canvas.clientHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (gameIntro) {
      drawGameIntro(ctx, canvas.width, canvas.height)
      return
    }

    if (viewState === "planet" || zoomTarget) {
      drawPlanetView(ctx, canvas.width, canvas.height)
    }

    if (viewState === "region" || zoomTarget) {
      drawRegionView(ctx, canvas.width, canvas.height)
    }
  }, [
    resources,
    mode,
    viewState,
    selectedRegion,
    hoveredPoint,
    showCommunityInitiatives,
    hoveredRegion,
    zoomTarget,
    zoomTransition,
    gameIntro,
    gameStage,
  ])

  const drawGameIntro = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Create a dark background
    ctx.fillStyle = "#0a0a0a"
    ctx.fillRect(0, 0, width, height)

    // Add stars
    for (let i = 0; i < 200; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 1.5
      const opacity = Math.random() * 0.8 + 0.2

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
      ctx.fill()
    }

    // Draw intro text based on game stage
    ctx.textAlign = "center"
    ctx.fillStyle = "white"

    if (gameStage === 0) {
      ctx.font = 'bold 36px "Inter", sans-serif'
      ctx.fillText("DIGITAL EXTRACTION", width / 2, height / 2 - 40)
      ctx.font = 'bold 24px "Inter", sans-serif'
      ctx.fillText("The Hidden Material Costs of AI", width / 2, height / 2 + 10)
    } else if (gameStage === 1) {
      ctx.font = 'bold 28px "Inter", sans-serif'
      ctx.fillText("Every AI interaction has a physical cost", width / 2, height / 2 - 60)

      ctx.font = '18px "Inter", sans-serif'
      ctx.fillText("Water for cooling data centers", width / 2, height / 2 - 10)
      ctx.fillText("Minerals extracted from the earth", width / 2, height / 2 + 20)
      ctx.fillText("Energy consumed by servers", width / 2, height / 2 + 50)
    } else if (gameStage === 2) {
      ctx.font = 'bold 28px "Inter", sans-serif'
      ctx.fillText("Explore the planetary impact", width / 2, height / 2 - 40)

      // Draw a small planet
      const planetRadius = 80
      const centerX = width / 2
      const centerY = height / 2 + 60

      ctx.beginPath()
      ctx.arc(centerX, centerY, planetRadius, 0, Math.PI * 2)
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, planetRadius)
      gradient.addColorStop(0, "#3d0c02")
      gradient.addColorStop(0.7, "#2d1b00")
      gradient.addColorStop(1, "#1c0f00")
      ctx.fillStyle = gradient
      ctx.fill()

      // Draw grid lines
      ctx.strokeStyle = "rgba(255, 255, 255, 0.2)"
      ctx.lineWidth = 1

      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2
        ctx.beginPath()
        ctx.moveTo(centerX, centerY)
        ctx.lineTo(centerX + Math.cos(angle) * planetRadius, centerY + Math.sin(angle) * planetRadius)
        ctx.stroke()
      }

      // Draw latitude circles
      for (let i = 1; i <= 3; i++) {
        ctx.beginPath()
        ctx.arc(centerX, centerY, planetRadius * (i / 3), 0, Math.PI * 2)
        ctx.stroke()
      }
    } else if (gameStage === 3) {
      ctx.font = 'bold 28px "Inter", sans-serif'
      ctx.fillText("Click on regions to zoom in", width / 2, height / 2 - 60)
      ctx.fillText("and discover their stories", width / 2, height / 2 - 20)

      ctx.font = '18px "Inter", sans-serif'
      ctx.fillText("Click anywhere to begin", width / 2, height / 2 + 60)
    }
  }

  const drawPlanetView = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Create a space-like background
    const gradient = ctx.createRadialGradient(width / 2, height / 2, 10, width / 2, height / 2, width)

    if (mode === "extractive") {
      gradient.addColorStop(0, "#1c0f00")
      gradient.addColorStop(1, "#2b0504")
    } else {
      gradient.addColorStop(0, "#0f2601")
      gradient.addColorStop(1, "#0d1f00")
    }

    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Add stars in the background
    for (let i = 0; i < 100; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 1.5
      const opacity = Math.random() * 0.8 + 0.2

      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
      ctx.fill()
    }

    // Calculate planet position and size based on zoom transition
    let centerX = width / 2
    let centerY = height / 2
    let radius = Math.min(width, height) * 0.35

    if (zoomTarget && viewState === "planet") {
      // When zooming in from planet to region
      centerX = width / 2 + (zoomTarget.x * width - width / 2) * zoomTransition
      centerY = height / 2 + (zoomTarget.y * height - height / 2) * zoomTransition
      radius = Math.min(width, height) * (0.35 + zoomTransition * 2)
    } else if (zoomTarget && viewState === "region") {
      // When zooming out from region to planet
      centerX = zoomTarget.x * width + (width / 2 - zoomTarget.x * width) * zoomTransition
      centerY = zoomTarget.y * height + (height / 2 - zoomTarget.y * height) * zoomTransition
      radius = Math.min(width, height) * (2.35 - zoomTransition * 2)
    }

    // Draw the planet base
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    const globeGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius)

    if (mode === "extractive") {
      globeGradient.addColorStop(0, "#8b0000")
      globeGradient.addColorStop(0.7, "#a52a2a")
      globeGradient.addColorStop(1, "#cd5c5c")
    } else {
      globeGradient.addColorStop(0, "#2e5902")
      globeGradient.addColorStop(0.7, "#3a7d44")
      globeGradient.addColorStop(1, "#57a773")
    }

    ctx.fillStyle = globeGradient
    ctx.fill()

    // Add a subtle glow
    ctx.shadowColor = mode === "extractive" ? "#cd5c5c" : "#57a773"
    ctx.shadowBlur = 20
    ctx.fill()
    ctx.shadowBlur = 0

    // Draw latitude/longitude grid
    ctx.strokeStyle = "rgba(255, 255, 255, 0.1)"
    ctx.lineWidth = 1

    // Latitude lines
    for (let i = 1; i <= 5; i++) {
      const latRadius = radius * (i / 6)
      ctx.beginPath()
      ctx.arc(centerX, centerY, latRadius, 0, Math.PI * 2)
      ctx.stroke()
    }

    // Longitude lines
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.lineTo(centerX + Math.cos(angle) * radius, centerY + Math.sin(angle) * radius)
      ctx.stroke()
    }

    // Draw data flow around the globe
    for (let i = 0; i < 20; i++) {
      const startAngle = Math.random() * Math.PI * 2
      const endAngle = startAngle + (Math.random() * Math.PI - Math.PI / 2)
      const startRadius = radius * 0.8
      const endRadius = radius * 1.2

      const startX = centerX + Math.cos(startAngle) * startRadius
      const startY = centerY + Math.sin(startAngle) * startRadius
      const endX = centerX + Math.cos(endAngle) * endRadius
      const endY = centerY + Math.sin(endAngle) * endRadius

      const progress = (Date.now() % 3000) / 3000

      ctx.beginPath()
      ctx.moveTo(startX, startY)
      ctx.lineTo(startX + (endX - startX) * progress, startY + (endY - startY) * progress)
      ctx.strokeStyle = mode === "extractive" ? "rgba(233, 69, 96, 0.5)" : "rgba(106, 153, 78, 0.5)"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw pulse at the end of the line
      ctx.beginPath()
      ctx.arc(startX + (endX - startX) * progress, startY + (endY - startY) * progress, 2, 0, Math.PI * 2)
      ctx.fillStyle = mode === "extractive" ? "#e94560" : "#6a994e"
      ctx.fill()
    }

    // Only draw regions if we're in planet view or transitioning from planet to region
    if (viewState === "planet" || (zoomTarget && viewState === "region")) {
      // Draw regions on the globe
      REGIONS.forEach((region) => {
        // Convert position to coordinates on the globe
        const x = centerX + (region.position.x - 0.5) * radius * 2
        const y = centerY + (region.position.y - 0.5) * radius * 2

        const isHovered = hoveredRegion && hoveredRegion.id === region.id

        // Draw region marker
        ctx.beginPath()
        ctx.arc(x, y, isHovered ? 15 : 10, 0, Math.PI * 2)

        // Color based on mode and hover state
        if (mode === "extractive") {
          ctx.fillStyle = isHovered ? "#ff6b35" : "#cc5129"
        } else {
          ctx.fillStyle = isHovered ? "#6a994e" : "#386641"
        }

        ctx.fill()

        // Add glow effect if hovered
        if (isHovered) {
          ctx.shadowColor = mode === "extractive" ? "#ff6b35" : "#6a994e"
          ctx.shadowBlur = 15
          ctx.fill()
          ctx.shadowBlur = 0

          // Draw region name
          ctx.font = isHovered ? 'bold 14px "Inter", sans-serif' : '12px "Inter", sans-serif'
          ctx.fillStyle = "white"
          ctx.textAlign = "center"
          ctx.fillText(region.name, x, y - 20)

          // Draw pulsing circle for extraction activity
          if (mode === "extractive") {
            const pulseSize = 20 + Math.sin(Date.now() * 0.003) * 5
            ctx.beginPath()
            ctx.arc(x, y, pulseSize, 0, Math.PI * 2)
            ctx.fillStyle = "rgba(255, 107, 53, 0.1)"
            ctx.fill()
          }

          // Draw connections between regions
          if (mode === "extractive") {
            // Connect data centers to resource regions
            if (region.id === "siliconvalley" || region.id === "canada") {
              REGIONS.filter((r) => r.id !== region.id && r.id !== "canada").forEach((resourceRegion) => {
                const rx = centerX + (resourceRegion.position.x - 0.5) * radius * 2
                const ry = centerY + (resourceRegion.position.y - 0.5) * radius * 2

                ctx.beginPath()
                ctx.moveTo(x, y)

                // Draw curved line
                const controlX = (x + rx) / 2
                const controlY = (y + ry) / 2 - 30
                ctx.quadraticCurveTo(controlX, controlY, rx, ry)

                ctx.strokeStyle = "rgba(255, 107, 53, 0.3)"
                ctx.lineWidth = 1
                ctx.stroke()

                // Animated flow along the connection
                const flowPosition = (Date.now() % 3000) / 3000
                const flowX = x + (rx - x) * flowPosition
                const flowY = y + (ry - y) * flowPosition

                ctx.beginPath()
                ctx.arc(flowX, flowY, 3, 0, Math.PI * 2)
                ctx.fillStyle = "rgba(255, 107, 53, 0.7)"
                ctx.fill()
              })
            }
          } else {
            // In sustainable mode, connect community initiatives
            if (region.id === "canada" || region.id === "amazonia") {
              REGIONS.filter((r) => r.id !== region.id).forEach((otherRegion) => {
                const rx = centerX + (otherRegion.position.x - 0.5) * radius * 2
                const ry = centerY + (otherRegion.position.y - 0.5) * radius * 2

                ctx.beginPath()
                ctx.moveTo(x, y)

                // Draw curved line
                const controlX = (x + rx) / 2
                const controlY = (y + ry) / 2 - 30
                ctx.quadraticCurveTo(controlX, controlY, rx, ry)

                ctx.strokeStyle = "rgba(106, 153, 78, 0.3)"
                ctx.lineWidth = 1
                ctx.stroke()

                // Animated flow along the connection
                const flowPosition = (Date.now() % 3000) / 3000
                const flowX = x + (rx - x) * flowPosition
                const flowY = y + (ry - y) * flowPosition

                ctx.beginPath()
                ctx.arc(flowX, flowY, 2, 0, Math.PI * 2)
                ctx.fillStyle = "rgba(106, 153, 78, 0.7)"
                ctx.fill()
              })
            }
          }
        }
      })
    }

    // Draw real-time global stats
    ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
    ctx.fillRect(width - 280, 20, 260, 180)

    ctx.font = 'bold 16px "Inter", sans-serif'
    ctx.fillStyle = mode === "extractive" ? "#ff6b35" : "#6a994e"
    ctx.textAlign = "left"
    ctx.fillText("GLOBAL REAL-TIME METRICS", width - 270, 45)

    ctx.font = '12px "Inter", sans-serif'
    ctx.fillStyle = "rgba(255, 255, 255, 0.7)"
    ctx.fillText(`Last updated: ${lastUpdate.toLocaleTimeString()}`, width - 270, 65)

    // Draw metrics
    const metrics = [
      { icon: Droplet, label: "Water Usage", value: `${realTimeData.globalWaterUsage.toLocaleString()} L/min` },
      { icon: Cpu, label: "Active Data Centers", value: realTimeData.activeDataCenters.toLocaleString() },
      { icon: Zap, label: "AI Models Training", value: realTimeData.aiModelTraining.toLocaleString() },
      {
        icon: AlertTriangle,
        label: "Carbon Emissions",
        value: `${realTimeData.carbonEmissions.toLocaleString()} tons/hr`,
      },
      { icon: Users, label: "Community Initiatives", value: realTimeData.communityInitiatives.toLocaleString() },
    ]

    metrics.forEach((metric, index) => {
      const y = 90 + index * 25

      // Draw icon
      ctx.fillStyle = "white"
      ctx.font = '14px "lucide"'
      const IconComponent = metric.icon
      ctx.fillText(IconComponent.toString(), width - 270, y)

      // Draw label and value
      ctx.font = '14px "Inter", sans-serif'
      ctx.fillStyle = "white"
      ctx.fillText(metric.label, width - 245, y)

      ctx.font = 'bold 14px "Inter", sans-serif'
      ctx.fillStyle = mode === "extractive" ? "#ff6b35" : "#6a994e"
      ctx.textAlign = "right"
      ctx.fillText(metric.value, width - 30, y)
      ctx.textAlign = "left"
    })

    // Draw instructions
    if (viewState === "planet" && !zoomTarget) {
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(20, height - 60, 300, 40)

      ctx.font = '14px "Inter", sans-serif'
      ctx.fillStyle = "white"
      ctx.textAlign = "left"
      ctx.fillText("Click on a region to explore its extraction impact", 30, height - 35)
    }
  }

  const drawRegionView = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    if (!selectedRegion && !zoomTarget) return

    const region =
      selectedRegion ||
      (zoomTarget
        ? REGIONS.find(
            (r) => Math.abs(r.position.x - zoomTarget.x) < 0.1 && Math.abs(r.position.y - zoomTarget.y) < 0.1,
          )
        : null)

    if (!region) return

    // Create a futuristic background
    const gradient = ctx.createRadialGradient(width / 2, height / 2, 10, width / 2, height / 2, width)

    if (mode === "extractive") {
      gradient.addColorStop(0, "#2d1b00")
      gradient.addColorStop(1, "#3d0c02")
    } else {
      gradient.addColorStop(0, "#1e3a00")
      gradient.addColorStop(1, "#1e3205")
    }

    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Calculate opacity based on zoom transition
    let opacity = 1
    if (zoomTarget) {
      opacity = viewState === "planet" ? zoomTransition : 1 - zoomTransition
    }

    // Draw futuristic grid
    ctx.strokeStyle =
      mode === "extractive" ? `rgba(255, 107, 53, ${0.2 * opacity})` : `rgba(106, 153, 78, ${0.2 * opacity})`
    ctx.lineWidth = 1

    // Draw horizontal grid lines
    for (let y = 0; y < height; y += 30) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(width, y)
      ctx.stroke()
    }

    // Draw vertical grid lines
    for (let x = 0; x < width; x += 30) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }

    // Draw region name in a futuristic style
    ctx.font = 'bold 24px "Inter", sans-serif'
    ctx.fillStyle = mode === "extractive" ? `rgba(255, 107, 53, ${opacity})` : `rgba(106, 153, 78, ${opacity})`
    ctx.textAlign = "center"
    ctx.fillText(region.name, width / 2, 40)

    // Draw abstract extraction symbol - concentric circles with radiating lines
    const centerX = width / 2
    const centerY = height / 2

    // Draw concentric circles
    for (let i = 1; i <= 5; i++) {
      const radius = Math.min(width, height) * 0.1 * i
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.strokeStyle =
        mode === "extractive"
          ? `rgba(255, 107, 53, ${(0.1 + i * 0.05) * opacity})`
          : `rgba(106, 153, 78, ${(0.1 + i * 0.05) * opacity})`
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw radiating lines
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2
      const innerRadius = Math.min(width, height) * 0.05
      const outerRadius = Math.min(width, height) * 0.5

      ctx.beginPath()
      ctx.moveTo(centerX + Math.cos(angle) * innerRadius, centerY + Math.sin(angle) * innerRadius)
      ctx.lineTo(centerX + Math.cos(angle) * outerRadius, centerY + Math.sin(angle) * outerRadius)
      ctx.strokeStyle =
        mode === "extractive" ? `rgba(255, 107, 53, ${0.3 * opacity})` : `rgba(106, 153, 78, ${0.3 * opacity})`
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw extraction points along the radiating lines
    region.extractionPoints.forEach((point, index) => {
      const angle = ((index % 12) / 12) * Math.PI * 2
      const distance = ((point.x + point.y) / 2) * Math.min(width, height) * 0.5
      const x = centerX + Math.cos(angle) * distance
      const y = centerY + Math.sin(angle) * distance

      // Store the calculated position for later use
      point.calculatedX = x
      point.calculatedY = y

      const isHovered = hoveredPoint && hoveredPoint.name === point.name

      // Draw hexagonal shape for extraction points
      ctx.beginPath()
      for (let i = 0; i < 6; i++) {
        const pointAngle = (i / 6) * Math.PI * 2
        const radius = isHovered ? 15 : 10
        const px = x + Math.cos(pointAngle) * radius
        const py = y + Math.sin(pointAngle) * radius
        if (i === 0) {
          ctx.moveTo(px, py)
        } else {
          ctx.lineTo(px, py)
        }
      }
      ctx.closePath()

      // Color based on type with earthy palette
      switch (point.type) {
        case "minerals":
          ctx.fillStyle = `rgba(255, 195, 0, ${opacity})`
          break
        case "energy":
          ctx.fillStyle = `rgba(255, 119, 0, ${opacity})`
          break
        case "water":
          ctx.fillStyle = `rgba(0, 150, 199, ${opacity})`
          break
        case "biodiversity":
          ctx.fillStyle = `rgba(64, 145, 108, ${opacity})`
          break
        case "community":
          ctx.fillStyle = `rgba(255, 77, 109, ${opacity})`
          break
        case "dataStorage":
          ctx.fillStyle = `rgba(90, 24, 154, ${opacity})`
          break
        default:
          ctx.fillStyle = `rgba(184, 192, 255, ${opacity})`
      }

      ctx.fill()

      // Add glow effect
      if (isHovered) {
        ctx.shadowColor = ctx.fillStyle
        ctx.shadowBlur = 15
        ctx.fill()
        ctx.shadowBlur = 0
      }

      // Draw pulse effect for extraction points in extractive mode
      if (mode === "extractive") {
        const pulseSize = 20 + Math.sin(Date.now() * 0.005) * 5
        ctx.beginPath()
        ctx.arc(x, y, pulseSize, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(233, 69, 96, ${0.1 * opacity})`
        ctx.fill()
      }

      // Draw label if hovered
      if (isHovered) {
        // Draw futuristic label background
        const textWidth = ctx.measureText(point.name).width
        ctx.fillStyle = `rgba(0, 0, 0, ${0.7 * opacity})`
        ctx.fillRect(x - textWidth / 2 - 10, y - 40, textWidth + 20, 25)

        // Draw label text
        ctx.font = '14px "Inter", sans-serif'
        ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
        ctx.textAlign = "center"
        ctx.fillText(point.name, x, y - 25)
      }
    })

    // Draw data centers
    if (region.dataCenters) {
      region.dataCenters.forEach((dc) => {
        const x = dc.x * width
        const y = dc.y * height
        const isHovered = hoveredPoint && hoveredPoint.name === dc.name

        // Draw data center icon (futuristic server)
        ctx.fillStyle = `rgba(123, 44, 191, ${opacity})`

        // Draw a more complex data center shape
        ctx.beginPath()
        ctx.moveTo(x - 12, y - 12)
        ctx.lineTo(x + 12, y - 12)
        ctx.lineTo(x + 15, y - 8)
        ctx.lineTo(x + 15, y + 8)
        ctx.lineTo(x + 12, y + 12)
        ctx.lineTo(x - 12, y + 12)
        ctx.lineTo(x - 15, y + 8)
        ctx.lineTo(x - 15, y - 8)
        ctx.closePath()
        ctx.fill()

        // Add glow effect
        if (isHovered) {
          ctx.shadowColor = "#9d4edd"
          ctx.shadowBlur = 15
          ctx.fill()
          ctx.shadowBlur = 0
        }

        // Draw internal lines to represent servers
        ctx.strokeStyle = `rgba(255, 255, 255, ${0.5 * opacity})`
        ctx.beginPath()
        ctx.moveTo(x - 10, y - 4)
        ctx.lineTo(x + 10, y - 4)
        ctx.stroke()

        ctx.beginPath()
        ctx.moveTo(x - 10, y + 4)
        ctx.lineTo(x + 10, y + 4)
        ctx.stroke()

        // Draw blinking lights
        const blinkState = Math.floor(Date.now() / 500) % 2 === 0
        ctx.fillStyle = blinkState ? `rgba(76, 201, 240, ${opacity})` : `rgba(247, 37, 133, ${opacity})`
        ctx.beginPath()
        ctx.arc(x + 8, y - 8, 2, 0, Math.PI * 2)
        ctx.fill()

        // Draw label if hovered
        if (isHovered) {
          // Draw futuristic label background
          const textWidth = Math.max(
            ctx.measureText(dc.name).width,
            ctx.measureText(`Water: ${dc.waterUsage} | Power: ${dc.powerCapacity}`).width,
          )

          ctx.fillStyle = `rgba(0, 0, 0, ${0.7 * opacity})`
          ctx.fillRect(x - textWidth / 2 - 10, y - 55, textWidth + 20, 45)

          // Draw label text
          ctx.font = '14px "Inter", sans-serif'
          ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
          ctx.textAlign = "center"
          ctx.fillText(dc.name, x, y - 40)

          ctx.font = '12px "Inter", sans-serif'
          ctx.fillText(`Water: ${dc.waterUsage} | Power: ${dc.powerCapacity}`, x, y - 20)
        }

        // Draw water usage visualization
        if (mode === "extractive") {
          const waterUsageIntensity =
            dc.waterUsage === "Extreme"
              ? 0.8
              : dc.waterUsage === "Very High"
                ? 0.6
                : dc.waterUsage === "High"
                  ? 0.4
                  : dc.waterUsage === "Medium"
                    ? 0.2
                    : 0.1

          const pulseSize = 30 + Math.sin(Date.now() * 0.003) * 10
          ctx.beginPath()
          ctx.arc(x, y, pulseSize, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(0, 150, 199, ${waterUsageIntensity * 0.3 * opacity})`
          ctx.fill()
        }
      })
    }

    // Draw water consumption areas
    if (region.waterConsumption) {
      region.waterConsumption.forEach((wc) => {
        const x = wc.x * width
        const y = wc.y * height
        const isHovered = hoveredPoint && hoveredPoint.name === wc.name

        // Determine intensity of color based on consumption
        const intensityValue =
          wc.intensity === "Critical"
            ? 0.9
            : wc.intensity === "Extreme"
              ? 0.7
              : wc.intensity === "Very High"
                ? 0.5
                : wc.intensity === "Severe"
                  ? 0.4
                  : wc.intensity === "High"
                    ? 0.3
                    : 0.2

        // Draw water consumption area
        const gradient = ctx.createRadialGradient(x, y, 5, x, y, 40)
        gradient.addColorStop(0, `rgba(0, 150, 199, ${intensityValue * opacity})`)
        gradient.addColorStop(1, `rgba(0, 150, 199, 0)`)

        ctx.beginPath()
        ctx.arc(x, y, 40, 0, Math.PI * 2)
        ctx.fillStyle = gradient
        ctx.fill()

        // Add animated ripple effect
        const rippleSize = 20 + Math.sin(Date.now() * 0.002) * 15
        ctx.beginPath()
        ctx.arc(x, y, rippleSize, 0, Math.PI * 2)
        ctx.strokeStyle = `rgba(0, 150, 199, ${intensityValue * 0.8 * opacity})`
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw water droplet icon
        ctx.beginPath()
        ctx.moveTo(x, y - 10)
        ctx.bezierCurveTo(x - 5, y - 5, x - 10, y, x, y + 10)
        ctx.bezierCurveTo(x + 10, y, x + 5, y - 5, x, y - 10)
        ctx.fillStyle = `rgba(0, 150, 199, ${0.8 * opacity})`
        ctx.fill()

        // Add glow effect if hovered
        if (isHovered) {
          ctx.shadowColor = "#0096c7"
          ctx.shadowBlur = 15
          ctx.fill()
          ctx.shadowBlur = 0

          // Draw label background
          const textWidth = Math.max(
            ctx.measureText(wc.name).width,
            ctx.measureText(`Consumption: ${wc.intensity}`).width,
          )

          ctx.fillStyle = `rgba(0, 0, 0, ${0.7 * opacity})`
          ctx.fillRect(x - textWidth / 2 - 10, y - 55, textWidth + 20, 45)

          // Draw label text
          ctx.font = '14px "Inter", sans-serif'
          ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
          ctx.textAlign = "center"
          ctx.fillText(wc.name, x, y - 40)

          ctx.font = '12px "Inter", sans-serif'
          ctx.fillText(`Consumption: ${wc.intensity}`, x, y - 20)
        }
      })
    }

    // Draw connections between data centers and water consumption areas
    if (region.dataCenters && region.waterConsumption && mode === "extractive") {
      ctx.strokeStyle = `rgba(0, 150, 199, ${0.3 * opacity})`
      ctx.lineWidth = 1
      ctx.setLineDash([4, 4])

      region.dataCenters.forEach((dc) => {
        const dcX = dc.x * width
        const dcY = dc.y * height

        region.waterConsumption.forEach((wc) => {
          const wcX = wc.x * width
          const wcY = wc.y * height

          ctx.beginPath()
          ctx.moveTo(dcX, dcY)
          ctx.lineTo(wcX, wcY)
          ctx.stroke()

          // Animated flow of data/water
          const flowPosition = (Date.now() % 3000) / 3000
          const flowX = dcX + (wcX - dcX) * flowPosition
          const flowY = dcY + (wcY - dcY) * flowPosition

          ctx.beginPath()
          ctx.arc(flowX, flowY, 3, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(0, 150, 199, ${0.8 * opacity})`
          ctx.fill()
        })
      })

      ctx.setLineDash([])
    }

    // Draw community initiatives if enabled
    if (showCommunityInitiatives && region.communityInitiatives) {
      region.communityInitiatives.forEach((initiative) => {
        const x = initiative.x * width
        const y = initiative.y * height
        const isHovered = hoveredPoint && hoveredPoint.name === initiative.name

        // Draw community initiative icon (network of people)
        ctx.beginPath()
        ctx.arc(x, y, isHovered ? 15 : 12, 0, Math.PI * 2)
        ctx.fillStyle =
          mode === "extractive" ? `rgba(130, 201, 30, ${0.8 * opacity})` : `rgba(130, 201, 30, ${opacity})`
        ctx.fill()

        // Draw people icon inside
        ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
        ctx.beginPath()
        ctx.arc(x - 4, y - 2, 3, 0, Math.PI * 2) // Head 1
        ctx.fill()
        ctx.beginPath()
        ctx.arc(x + 4, y - 2, 3, 0, Math.PI * 2) // Head 2
        ctx.fill()
        ctx.beginPath()
        ctx.arc(x, y + 4, 3, 0, Math.PI * 2) // Head 3
        ctx.fill()

        // Add connecting lines between people
        ctx.strokeStyle = `rgba(255, 255, 255, ${opacity})`
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(x - 4, y - 2)
        ctx.lineTo(x + 4, y - 2)
        ctx.moveTo(x - 4, y - 2)
        ctx.lineTo(x, y + 4)
        ctx.moveTo(x + 4, y - 2)
        ctx.lineTo(x, y + 4)
        ctx.stroke()

        // Add glow effect
        if (isHovered || mode === "sustainable") {
          ctx.shadowColor = "#82c91e"
          ctx.shadowBlur = 15
          ctx.beginPath()
          ctx.arc(x, y, isHovered ? 15 : 12, 0, Math.PI * 2)
          ctx.fill()
          ctx.shadowBlur = 0
        }

        // Draw pulse effect for community initiatives in sustainable mode
        if (mode === "sustainable") {
          const pulseSize = 20 + Math.sin(Date.now() * 0.005) * 5
          ctx.beginPath()
          ctx.arc(x, y, pulseSize, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(130, 201, 30, ${0.1 * opacity})`
          ctx.fill()

          // Draw connection lines to other community initiatives
          const otherInitiatives = region.communityInitiatives.filter((i) => i !== initiative)
          ctx.strokeStyle = `rgba(130, 201, 30, ${0.3 * opacity})`
          ctx.lineWidth = 1

          otherInitiatives.forEach((other) => {
            const otherX = other.x * width
            const otherY = other.y * height

            ctx.beginPath()
            ctx.moveTo(x, y)
            ctx.lineTo(otherX, otherY)
            ctx.stroke()

            // Animated flow of knowledge/data
            const flowPosition = (Date.now() % 3000) / 3000
            const flowX = x + (otherX - x) * flowPosition
            const flowY = y + (otherY - y) * flowPosition

            ctx.beginPath()
            ctx.arc(flowX, flowY, 2, 0, Math.PI * 2)
            ctx.fillStyle = `rgba(130, 201, 30, ${0.8 * opacity})`
            ctx.fill()
          })
        }

        // Draw label if hovered
        if (isHovered) {
          // Draw label background
          const textWidth = Math.max(
            ctx.measureText(initiative.name).width,
            ctx.measureText(initiative.description).width,
          )

          ctx.fillStyle = `rgba(0, 0, 0, ${0.7 * opacity})`
          ctx.fillRect(x - textWidth / 2 - 10, y - 75, textWidth + 20, 65)

          // Draw label text
          ctx.font = 'bold 14px "Inter", sans-serif'
          ctx.fillStyle = `rgba(130, 201, 30, ${opacity})`
          ctx.textAlign = "center"
          ctx.fillText(initiative.name, x, y - 60)

          ctx.font = '12px "Inter", sans-serif'
          ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
          ctx.fillText(initiative.description, x, y - 40)

          ctx.font = '12px "Inter", sans-serif'
          ctx.fillText(`Impact: ${initiative.impact}`, x, y - 20)
        }
      })
    }

    // Draw legend
    ctx.fillStyle = `rgba(0, 0, 0, ${0.7 * opacity})`
    ctx.fillRect(10, height - 190, 200, 180)

    ctx.font = 'bold 14px "Inter", sans-serif'
    ctx.fillStyle = mode === "extractive" ? `rgba(255, 107, 53, ${opacity})` : `rgba(106, 153, 78, ${opacity})`
    ctx.textAlign = "left"
    ctx.fillText("LEGEND", 20, height - 170)

    const legendItems = [
      { color: "#ffc300", label: "Minerals" },
      { color: "#ff7700", label: "Energy" },
      { color: "#0096c7", label: "Water" },
      { color: "#40916c", label: "Biodiversity" },
      { color: "#ff4d6d", label: "Community" },
      { color: "#5a189a", label: "Data Centers" },
      { color: "rgba(0, 150, 199, 0.5)", label: "Water Consumption" },
    ]

    if (showCommunityInitiatives) {
      legendItems.push({ color: "#82c91e", label: "Community Initiatives" })
    }

    legendItems.forEach((item, index) => {
      const y = height - 145 + index * 20

      if (item.label === "Water Consumption") {
        // Draw water droplet for water consumption
        ctx.beginPath()
        ctx.moveTo(25, y - 3)
        ctx.bezierCurveTo(22, y, 20, y + 3, 25, y + 6)
        ctx.bezierCurveTo(30, y + 3, 28, y, 25, y - 3)
        ctx.fillStyle = item.color
        ctx.fill()
      } else if (item.label === "Data Centers") {
        // Draw hexagon for data centers
        ctx.fillStyle = item.color
        ctx.beginPath()
        for (let i = 0; i < 6; i++) {
          const angle = (i / 6) * Math.PI * 2 + Math.PI / 6
          const px = 25 + Math.cos(angle) * 6
          const py = y + Math.sin(angle) * 6
          if (i === 0) {
            ctx.moveTo(px, py)
          } else {
            ctx.lineTo(px, py)
          }
        }
        ctx.closePath()
        ctx.fill()
      } else if (item.label === "Community Initiatives") {
        // Draw community icon
        ctx.beginPath()
        ctx.arc(25, y, 6, 0, Math.PI * 2)
        ctx.fillStyle = item.color
        ctx.fill()

        // Draw simplified people icon
        ctx.fillStyle = "white"
        ctx.beginPath()
        ctx.arc(25, y, 2, 0, Math.PI * 2)
        ctx.fill()
      } else {
        // Draw hexagon for other items
        ctx.fillStyle = item.color
        ctx.beginPath()
        for (let i = 0; i < 6; i++) {
          const angle = (i / 6) * Math.PI * 2
          const px = 25 + Math.cos(angle) * 6
          const py = y + Math.sin(angle) * 6
          if (i === 0) {
            ctx.moveTo(px, py)
          } else {
            ctx.lineTo(px, py)
          }
        }
        ctx.closePath()
        ctx.fill()
      }

      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
      ctx.font = '12px "Inter", sans-serif'
      ctx.textAlign = "left"
      ctx.fillText(item.label, 40, y + 4)
    })

    // Draw instructions for returning to planet view
    if (viewState === "region" && !zoomTarget) {
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(20, height - 60, 300, 40)

      ctx.font = '14px "Inter", sans-serif'
      ctx.fillStyle = "white"
      ctx.textAlign = "left"
      ctx.fillText("Click the Home button to return to planet view", 30, height - 35)
    }
  }

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (gameIntro) {
      setGameIntro(false)
      return
    }

    if (zoomTarget) return // Don't handle clicks during transitions

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) / canvas.width
    const y = (e.clientY - rect.top) / canvas.height

    if (viewState === "planet") {
      // Check if clicked on a region
      const clickedRegion = REGIONS.find((region) => {
        const regionX = region.position.x
        const regionY = region.position.y
        const distance = Math.sqrt(Math.pow(regionX - x, 2) + Math.pow(regionY - y, 2))
        return distance < 0.05 // Threshold for clicking
      })

      if (clickedRegion) {
        setZoomTarget(clickedRegion.position)
      }
    }
  }

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (gameIntro || zoomTarget) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) / canvas.width
    const y = (e.clientY - rect.top) / canvas.height

    if (viewState === "planet") {
      // Check if hovering over a region
      const region = REGIONS.find((r) => {
        const distance = Math.sqrt(Math.pow(r.position.x - x, 2) + Math.pow(r.position.y - y, 2))
        return distance < 0.05 // Threshold for hover
      })

      setHoveredRegion(region || null)
      setHoveredPoint(null)
    } else if (viewState === "region" && selectedRegion) {
      // Check if hovering over an extraction point
      let point = selectedRegion.extractionPoints.find((p) => {
        const distance = Math.sqrt(Math.pow(p.x - x, 2) + Math.pow(p.y - y, 2))
        return distance < 0.03 // Threshold for hover
      })

      // Check data centers if no extraction point found
      if (!point && selectedRegion.dataCenters) {
        const dataCenter = selectedRegion.dataCenters.find((dc) => {
          const distance = Math.sqrt(Math.pow(dc.x - x, 2) + Math.pow(dc.y - y, 2))
          return distance < 0.03
        })

        if (dataCenter) {
          point = dataCenter
        }
      }

      // Check water consumption areas if still nothing found
      if (!point && selectedRegion.waterConsumption) {
        const waterArea = selectedRegion.waterConsumption.find((wc) => {
          const distance = Math.sqrt(Math.pow(wc.x - x, 2) + Math.pow(wc.y - y, 2))
          return distance < 0.04 // Slightly larger threshold for water areas
        })

        if (waterArea) {
          point = waterArea
        }
      }

      // Check community initiatives if enabled
      if (!point && showCommunityInitiatives && selectedRegion.communityInitiatives) {
        const initiative = selectedRegion.communityInitiatives.find((i) => {
          const distance = Math.sqrt(Math.pow(i.x - x, 2) + Math.pow(i.y - y, 2))
          return distance < 0.03
        })

        if (initiative) {
          point = initiative
        }
      }

      // For the abstract visualization, check if hovering over calculated positions
      if (!point && selectedRegion.extractionPoints) {
        point = selectedRegion.extractionPoints.find((p) => {
          if (!p.calculatedX || !p.calculatedY) return false
          const distance = Math.sqrt(
            Math.pow(p.calculatedX / canvas.width - x, 2) + Math.pow(p.calculatedY / canvas.height - y, 2),
          )
          return distance < 0.03
        })
      }

      setHoveredPoint(point || null)
      setHoveredRegion(null)
    }
  }

  const handleCanvasMouseLeave = () => {
    setHoveredPoint(null)
    setHoveredRegion(null)
  }

  const handleModeToggle = () => {
    setMode(mode === "extractive" ? "sustainable" : "extractive")
  }

  const resetSimulation = () => {
    if (selectedRegion) {
      setResources(selectedRegion.resources)
    }
    setTotalImpact(0)
  }

  const handleChatSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    handleSubmit(e)
  }

  const returnToPlanetView = () => {
    if (viewState === "region" && selectedRegion) {
      setZoomTarget(selectedRegion.position)
    }
  }

  const toggleCommunityInitiatives = () => {
    setShowCommunityInitiatives(!showCommunityInitiatives)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-white">
      <header className="p-4 bg-black/30 border-b border-gray-800">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Network className="h-8 w-8 mr-3 text-amber-500" />
            <div>
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-amber-500 to-red-700">
                Digital Extraction Matrix
              </h1>
              <p className="text-sm text-gray-400">The hidden material costs of artificial intelligence</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 justify-center">
            <Badge variant={mode === "extractive" ? "destructive" : "default"} className="text-xs">
              {mode === "extractive" ? "Extractive Mode" : "Sustainable Mode"}
            </Badge>
            <Badge variant="outline" className="text-xs flex items-center">
              <RefreshCw className="h-3 w-3 mr-1" />
              Updated: {lastUpdate.toLocaleTimeString()}
            </Badge>
            <Badge variant="secondary" className="text-xs">
              Water Usage: {realTimeData.globalWaterUsage.toLocaleString()} L/min
            </Badge>
          </div>
        </div>
      </header>

      <div className="flex flex-col md:flex-row flex-1 p-4 gap-4">
        <div className="w-full md:w-2/3 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-2">
              <Button
                onClick={handleModeToggle}
                variant={mode === "extractive" ? "destructive" : "default"}
                size="sm"
                className="bg-gradient-to-r from-amber-600 to-red-700 hover:from-amber-700 hover:to-red-800 text-white border-0"
              >
                {mode === "extractive" ? "Switch to Sustainable" : "Switch to Extractive"}
              </Button>

              <Button
                onClick={toggleCommunityInitiatives}
                variant="outline"
                size="sm"
                className={showCommunityInitiatives ? "border-green-500 text-green-500" : ""}
              >
                <Users className="h-4 w-4 mr-2" />
                {showCommunityInitiatives ? "Hide Initiatives" : "Show Initiatives"}
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              {viewState === "region" && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        onClick={returnToPlanetView}
                        variant="outline"
                        size="sm"
                        className="rounded-full w-10 h-10 p-0"
                        disabled={!!zoomTarget}
                      >
                        <Home className="h-5 w-5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Return to planet view</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}

              <Button onClick={() => setShowStats(!showStats)} variant="outline" size="sm">
                <BarChart3 className="mr-2 h-4 w-4" />
                {showStats ? "Hide Statistics" : "Show Statistics"}
              </Button>
            </div>
          </div>

          <div className="relative flex-1 border border-gray-700 rounded-lg overflow-hidden bg-black/20">
            <canvas
              ref={canvasRef}
              className="w-full h-full cursor-pointer"
              onClick={handleCanvasClick}
              onMouseMove={handleCanvasMouseMove}
              onMouseLeave={handleCanvasMouseLeave}
            />

            {viewState === "region" && selectedRegion && !gameIntro && (
              <div className="absolute top-4 left-4 bg-black/70 p-3 rounded-lg max-w-xs backdrop-blur-sm border border-gray-800">
                <div className="text-sm font-medium mb-1">{selectedRegion.name}</div>
                <div className="text-xs text-gray-400 mb-2">{selectedRegion.description}</div>
                {hoveredPoint && (
                  <div className="text-xs border-t border-gray-700 pt-2 mt-2">
                    <span className="font-medium text-blue-400">{hoveredPoint.name}</span>
                    {hoveredPoint.description && <p className="mt-1 text-gray-300">{hoveredPoint.description}</p>}
                  </div>
                )}
              </div>
            )}
          </div>

          {showStats && selectedRegion && (
            <Card className="mt-4 bg-black/50 border-gray-700">
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                  <div className="flex flex-col items-center">
                    <Droplet className="h-8 w-8 text-blue-500 mb-2" />
                    <div className="text-sm text-gray-400">Water</div>
                    <div className="text-xl font-bold">{Math.round(resources.water)}%</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <Cpu className="h-8 w-8 text-yellow-500 mb-2" />
                    <div className="text-sm text-gray-400">Energy</div>
                    <div className="text-xl font-bold">{Math.round(resources.energy)}%</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 flex items-center justify-center text-gray-400 mb-2">Li</div>
                    <div className="text-sm text-gray-400">Minerals</div>
                    <div className="text-xl font-bold">{Math.round(resources.minerals)}%</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <Leaf className="h-8 w-8 text-green-500 mb-2" />
                    <div className="text-sm text-gray-400">Biodiversity</div>
                    <div className="text-xl font-bold">{Math.round(resources.biodiversity)}%</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 flex items-center justify-center text-pink-500 mb-2">
                      <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" fill="none">
                        <circle cx="12" cy="5" r="3" />
                        <circle cx="5" cy="15" r="3" />
                        <circle cx="19" cy="15" r="3" />
                        <path d="M12 8v3m-7 4l3.5-3m10 0l-3.5-3" />
                      </svg>
                    </div>
                    <div className="text-sm text-gray-400">Community</div>
                    <div className="text-xl font-bold">{Math.round(resources.community)}%</div>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 flex items-center justify-center text-purple-500 mb-2">
                      <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" fill="none">
                        <rect x="2" y="4" width="20" height="16" rx="2" />
                        <path d="M6 8h.01M6 12h.01M6 16h.01M10 8h8M10 12h8M10 16h8" />
                      </svg>
                    </div>
                    <div className="text-sm text-gray-400">Data Storage</div>
                    <div className="text-xl font-bold">{Math.round(resources.dataStorage)}%</div>
                  </div>
                </div>

                <div className="mt-6">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-400">Total Impact</span>
                    <span className="text-sm font-medium">{Math.round(totalImpact)}</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div
                      className={`h-2.5 rounded-full ${mode === "extractive" ? "bg-gradient-to-r from-red-600 to-pink-600" : "bg-gradient-to-r from-green-500 to-teal-500"}`}
                      style={{ width: `${Math.min(totalImpact, 100)}%` }}
                    ></div>
                  </div>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button onClick={resetSimulation} variant="outline" size="sm">
                    Reset Simulation
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="w-full md:w-1/3">
          <Card className="h-full bg-black/50 border-gray-700">
            <CardContent className="p-4 flex flex-col h-full">
              <div className="flex-1 overflow-y-auto mb-4 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
                {messages.map((m) => (
                  <div key={m.id} className={`mb-4 ${m.role === "user" ? "text-right" : "text-left"}`}>
                    <span
                      className={`inline-block p-2 rounded-lg ${
                        m.role === "user"
                          ? "bg-blue-600 text-white"
                          : mode === "extractive"
                            ? "bg-gradient-to-r from-red-900/50 to-pink-900/50 text-white"
                            : "bg-gradient-to-r from-green-900/50 to-teal-900/50 text-white"
                      }`}
                    >
                      {m.content}
                    </span>
                  </div>
                ))}
                {isLoading && (
                  <div className="text-left">
                    <span className="inline-block p-2 rounded-lg bg-gray-700 text-white">Processing...</span>
                  </div>
                )}
              </div>

              <form onSubmit={handleChatSubmit} className="flex space-x-2">
                <Input
                  value={input}
                  onChange={handleInputChange}
                  placeholder={
                    selectedRegion
                      ? `Ask about ${selectedRegion.name}'s extraction impact...`
                      : "Ask about the material costs of AI..."
                  }
                  className="flex-grow bg-gray-800 border-gray-700"
                  disabled={!selectedRegion}
                />
                <Button
                  type="submit"
                  disabled={isLoading || !selectedRegion}
                  className="bg-gradient-to-r from-amber-600 to-red-700 hover:from-amber-700 hover:to-red-800 text-white"
                >
                  Send
                </Button>
              </form>

              <div className="mt-4 text-xs text-gray-500">
                {!selectedRegion ? (
                  <div className="flex items-center">
                    <AlertTriangle className="h-3 w-3 mr-1 text-amber-500" />
                    Select a region on the planet to explore its extraction impact
                  </div>
                ) : mode === "extractive" ? (
                  <div className="flex items-center">
                    <AlertTriangle className="h-3 w-3 mr-1 text-red-500" /> Each interaction consumes local resources
                    and affects communities
                  </div>
                ) : (
                  <div className="flex items-center">
                    <Leaf className="h-3 w-3 mr-1 text-green-500" /> Sustainable mode: lower impact and community
                    benefits
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

